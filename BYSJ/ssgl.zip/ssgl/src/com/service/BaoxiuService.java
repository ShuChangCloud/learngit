package com.service;
import java.util.List;
import com.model.Baoxiu;

public interface BaoxiuService
{
        public List<Baoxiu> queryBaoxiuList(Baoxiu baoxiu) throws Exception;
 
	public int insertBaoxiu(Baoxiu baoxiu) throws Exception ;
	
	public int deleteBaoxiu(int id) throws Exception ;
	
	public int updateBaoxiu(Baoxiu baoxiu) throws Exception ;
	
	public Baoxiu queryBaoxiuById(int id) throws Exception ;

}
