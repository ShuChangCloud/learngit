package com.service;
import java.util.List;
import com.model.Banji;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.Map;
import com.mapper.BanjiMapper;
@Service
public class BanjiServiceImpl implements BanjiService
{
        
        @Autowired
	private BanjiMapper banjiMapper;


	public List<Banji> queryBanjiList(Banji banji) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		if(banji!=null){
			 
		}
		
		List<Banji> getBanji = banjiMapper.query(map);
		return getBanji;
	}

	public int insertBanji(Banji banji) throws Exception {
		
		return banjiMapper.insertBanji(banji);
	}

	public int deleteBanji(int id) throws Exception {
		return banjiMapper.deleteBanji(id);
	}

	public int updateBanji(Banji banji) throws Exception {
		return banjiMapper.updateBanji(banji);
	}
	
	public Banji queryBanjiById(int id) throws Exception {
		return banjiMapper.queryBanjiById(id);
	}
 
}
