package com.service;
import java.util.List;
import com.model.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.Map;
import com.mapper.StudentMapper;
@Service
public class StudentServiceImpl implements StudentService
{
        
        @Autowired
	private StudentMapper studentMapper;


	public List<Student> queryStudentList(Student student) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		if(student!=null){
			 map.put("upwd", student.getUpwd());;
			 map.put("sno", student.getSno());;
			 map.put("sex", student.getSex());;
			 map.put("wfp", student.getWfp());;
			 map.put("state", student.getState());;
		}
		
		List<Student> getStudent = studentMapper.query(map);
		return getStudent;
	}

	public int insertStudent(Student student) throws Exception {
		
		return studentMapper.insertStudent(student);
	}

	public int deleteStudent(int id) throws Exception {
		return studentMapper.deleteStudent(id);
	}

	public int updateStudent(Student student) throws Exception {
		return studentMapper.updateStudent(student);
	}
	
	public Student queryStudentById(int id) throws Exception {
		return studentMapper.queryStudentById(id);
	}
 
}
