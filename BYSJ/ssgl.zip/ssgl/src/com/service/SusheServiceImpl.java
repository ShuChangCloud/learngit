package com.service;
import java.util.List;
import com.model.Sushe;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.Map;
import com.mapper.SusheMapper;
@Service
public class SusheServiceImpl implements SusheService
{
        
        @Autowired
	private SusheMapper susheMapper;


	public List<Sushe> querySusheList(Sushe sushe) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		if(sushe!=null){
			 
		}
		
		List<Sushe> getSushe = susheMapper.query(map);
		return getSushe;
	}
	
	public List<Sushe> querySushe(Sushe sushe) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		if(sushe!=null){
			map.put("sex", sushe.getSex());
		}
		List<Sushe> getSushe = susheMapper.querySushe(map);
		return getSushe;
	}
	
	public int insertSushe(Sushe sushe) throws Exception {
		
		return susheMapper.insertSushe(sushe);
	}

	public int deleteSushe(int id) throws Exception {
		return susheMapper.deleteSushe(id);
	}

	public int updateSushe(Sushe sushe) throws Exception {
		return susheMapper.updateSushe(sushe);
	}
	
	public Sushe querySusheById(int id) throws Exception {
		return susheMapper.querySusheById(id);
	}
 
}
