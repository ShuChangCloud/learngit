package com.service;
import java.util.List;
import com.model.Shuifei;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.Map;
import com.mapper.ShuifeiMapper;
@Service
public class ShuifeiServiceImpl implements ShuifeiService
{
        
        @Autowired
	private ShuifeiMapper shuifeiMapper;


	public List<Shuifei> queryShuifeiList(Shuifei shuifei) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		if(shuifei!=null){
			map.put("susheid", shuifei.getSusheid());
		}
		
		List<Shuifei> getShuifei = shuifeiMapper.query(map);
		return getShuifei;
	}
	public List<Shuifei> reportFee(Shuifei shuifei){
		Map<String, Object> map = new HashMap<String, Object>();
		if(shuifei!=null){
			 
		}
		
		List<Shuifei> getShuifei = shuifeiMapper.reportFee(map);
		return getShuifei;
	}
	public int insertShuifei(Shuifei shuifei) throws Exception {
		
		return shuifeiMapper.insertShuifei(shuifei);
	}

	public int deleteShuifei(int id) throws Exception {
		return shuifeiMapper.deleteShuifei(id);
	}

	public int updateShuifei(Shuifei shuifei) throws Exception {
		return shuifeiMapper.updateShuifei(shuifei);
	}
	
	public Shuifei queryShuifeiById(int id) throws Exception {
		return shuifeiMapper.queryShuifeiById(id);
	}
 
}
