package com.service;
import java.util.List;
import com.model.Gonggao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.Map;
import com.mapper.GonggaoMapper;
@Service
public class GonggaoServiceImpl implements GonggaoService
{
        
        @Autowired
	private GonggaoMapper gonggaoMapper;


	public List<Gonggao> queryGonggaoList(Gonggao gonggao) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		if(gonggao!=null){
			map.put("title", gonggao.getTitle());
			map.put("offset", gonggao.getOffset());
			map.put("pagesize", gonggao.getPagesize());
		}
		
		List<Gonggao> getGonggao = gonggaoMapper.query(map);
		return getGonggao;
	}

	public int insertGonggao(Gonggao gonggao) throws Exception {
		
		return gonggaoMapper.insertGonggao(gonggao);
	}

	public int deleteGonggao(int id) throws Exception {
		return gonggaoMapper.deleteGonggao(id);
	}

	public int updateGonggao(Gonggao gonggao) throws Exception {
		return gonggaoMapper.updateGonggao(gonggao);
	}
	
	public Gonggao queryGonggaoById(int id) throws Exception {
		return gonggaoMapper.queryGonggaoById(id);
	}
 
}
