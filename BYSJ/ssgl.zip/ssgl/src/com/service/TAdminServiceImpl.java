package com.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mapper.TAdminMapper;
import com.model.TAdmin;


@Service
public class TAdminServiceImpl implements TAdminService {
	@Autowired
	private TAdminMapper adminMapper;

	@Override
	public List<TAdmin> queryTAdminList(TAdmin admin) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		if(admin!=null){
			map.put("uname", admin.getUname());
			map.put("upwd", admin.getUpwd());
		}
		
		List<TAdmin> getTAdmin = adminMapper.query(map);
		return getTAdmin;
	}

	public int insertTAdmin(TAdmin admin) throws Exception {
		return adminMapper.insertTAdmin(admin);
	}

	public int deleteTAdmin(int id) throws Exception {
		return adminMapper.deleteTAdmin(id);
	}

	public int updateTAdmin(TAdmin admin) throws Exception {
		return adminMapper.updateTAdmin(admin);
	}
	
	public TAdmin queryTAdminById(int id) throws Exception {
		return adminMapper.queryTAdminById(id);
	}

 

 
}
