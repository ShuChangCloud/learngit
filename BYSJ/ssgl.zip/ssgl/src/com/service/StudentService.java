package com.service;
import java.util.List;
import com.model.Student;

public interface StudentService
{
        public List<Student> queryStudentList(Student student) throws Exception;
 
	public int insertStudent(Student student) throws Exception ;
	
	public int deleteStudent(int id) throws Exception ;
	
	public int updateStudent(Student student) throws Exception ;
	
	public Student queryStudentById(int id) throws Exception ;

}
