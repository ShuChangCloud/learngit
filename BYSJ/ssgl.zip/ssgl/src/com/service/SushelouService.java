package com.service;
import java.util.List;
import com.model.Sushelou;

public interface SushelouService
{
        public List<Sushelou> querySushelouList(Sushelou sushelou) throws Exception;
 
	public int insertSushelou(Sushelou sushelou) throws Exception ;
	
	public int deleteSushelou(int id) throws Exception ;
	
	public int updateSushelou(Sushelou sushelou) throws Exception ;
	
	public Sushelou querySushelouById(int id) throws Exception ;

}
