package com.service;
import java.util.List;
import com.model.Sushelou;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.Map;
import com.mapper.SushelouMapper;
@Service
public class SushelouServiceImpl implements SushelouService
{
        
        @Autowired
	private SushelouMapper sushelouMapper;


	public List<Sushelou> querySushelouList(Sushelou sushelou) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		if(sushelou!=null){
			 
		}
		
		List<Sushelou> getSushelou = sushelouMapper.query(map);
		return getSushelou;
	}

	public int insertSushelou(Sushelou sushelou) throws Exception {
		
		return sushelouMapper.insertSushelou(sushelou);
	}

	public int deleteSushelou(int id) throws Exception {
		return sushelouMapper.deleteSushelou(id);
	}

	public int updateSushelou(Sushelou sushelou) throws Exception {
		return sushelouMapper.updateSushelou(sushelou);
	}
	
	public Sushelou querySushelouById(int id) throws Exception {
		return sushelouMapper.querySushelouById(id);
	}
 
}
