package com.service;
import java.util.List;
import com.model.Banji;

public interface BanjiService
{
        public List<Banji> queryBanjiList(Banji banji) throws Exception;
 
	public int insertBanji(Banji banji) throws Exception ;
	
	public int deleteBanji(int id) throws Exception ;
	
	public int updateBanji(Banji banji) throws Exception ;
	
	public Banji queryBanjiById(int id) throws Exception ;

}
