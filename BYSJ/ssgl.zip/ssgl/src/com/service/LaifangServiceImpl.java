package com.service;
import java.util.List;
import com.model.Laifang;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.Map;
import com.mapper.LaifangMapper;
@Service
public class LaifangServiceImpl implements LaifangService
{
        
        @Autowired
	private LaifangMapper laifangMapper;


	public List<Laifang> queryLaifangList(Laifang laifang) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		if(laifang!=null){
			 
		}
		
		List<Laifang> getLaifang = laifangMapper.query(map);
		return getLaifang;
	}

	public int insertLaifang(Laifang laifang) throws Exception {
		
		return laifangMapper.insertLaifang(laifang);
	}

	public int deleteLaifang(int id) throws Exception {
		return laifangMapper.deleteLaifang(id);
	}

	public int updateLaifang(Laifang laifang) throws Exception {
		return laifangMapper.updateLaifang(laifang);
	}
	
	public Laifang queryLaifangById(int id) throws Exception {
		return laifangMapper.queryLaifangById(id);
	}
 
}
