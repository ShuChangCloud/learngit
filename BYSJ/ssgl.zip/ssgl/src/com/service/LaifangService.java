package com.service;
import java.util.List;
import com.model.Laifang;

public interface LaifangService
{
        public List<Laifang> queryLaifangList(Laifang laifang) throws Exception;
 
	public int insertLaifang(Laifang laifang) throws Exception ;
	
	public int deleteLaifang(int id) throws Exception ;
	
	public int updateLaifang(Laifang laifang) throws Exception ;
	
	public Laifang queryLaifangById(int id) throws Exception ;

}
