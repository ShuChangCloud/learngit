package com.service;
import java.util.List;
import com.model.Gonggao;

public interface GonggaoService
{
        public List<Gonggao> queryGonggaoList(Gonggao gonggao) throws Exception;
 
	public int insertGonggao(Gonggao gonggao) throws Exception ;
	
	public int deleteGonggao(int id) throws Exception ;
	
	public int updateGonggao(Gonggao gonggao) throws Exception ;
	
	public Gonggao queryGonggaoById(int id) throws Exception ;

}
