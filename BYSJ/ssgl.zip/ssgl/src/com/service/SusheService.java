package com.service;
import java.util.List;
import com.model.Sushe;

public interface SusheService
{
        public List<Sushe> querySusheList(Sushe sushe) throws Exception;
        public List<Sushe> querySushe(Sushe sushe) throws Exception;
	public int insertSushe(Sushe sushe) throws Exception ;
	
	public int deleteSushe(int id) throws Exception ;
	
	public int updateSushe(Sushe sushe) throws Exception ;
	
	public Sushe querySusheById(int id) throws Exception ;
	
}
