package com.service;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.directwebremoting.WebContext;
import org.directwebremoting.WebContextFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.Student;
import com.model.TAdmin;
@Service
public class loginService
{
	@Autowired
	private TAdminService tAdminService;
 
	@Autowired
	private StudentService studentService;
	public String login(String userName,String userPw,int userType) throws Exception
	{
		System.out.println("userType"+userType);
		try
		{
			Thread.sleep(700);
		} catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String result="no";
		
	    if(userType==0){ //����Ա
	    	TAdmin admin = new TAdmin();
			admin.setUname(userName);
			admin.setUpwd(userPw);
			
			List adminList=tAdminService.queryTAdminList(admin);
			if(adminList.size()==0)
			{
				 result="no";
			}
			else
			{
				 WebContext ctx = WebContextFactory.get(); 
				 HttpSession session=ctx.getSession(); 
				 TAdmin adminUser=(TAdmin)adminList.get(0);
				 session.setAttribute("userType", 0);
	             session.setAttribute("admin", adminUser);
	             session.setAttribute("banji",100);
	             result="yes";
			}
	    }
	    
	    if(userType==2){
	    	Student student = new Student();
	    	student.setSno(userName);
	    	student.setUpwd(userPw);
	    	student.setState("��У");
			List userList=studentService.queryStudentList(student);
			if(userList.size()==0)
			{
				 result="no";
			}
			else
			{
				 WebContext ctx = WebContextFactory.get(); 
				 HttpSession session=ctx.getSession(); 
				 Student uinfo=(Student)userList.get(0);
				 session.setAttribute("userType",2);
	             session.setAttribute("user", uinfo);
	             result="yes";
			}
	    }
		return result;
	}
 
	 
    public String adminPwEdit(String userPwNew) throws Exception
    {
		System.out.println("DDDD");
    	try 
		{
			Thread.sleep(700);
		} 
		catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebContext ctx = WebContextFactory.get(); 
		HttpSession session=ctx.getSession(); 
		 
		TAdmin admin=(TAdmin)session.getAttribute("admin");
		admin.setUpwd(userPwNew);
		tAdminService.updateTAdmin(admin);
		session.setAttribute("admin", admin);
		
		return "yes";
    }
    
    public String studentPwEdit(String userPwNew) throws Exception
    {
    	try 
		{
			Thread.sleep(700);
		} 
		catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebContext ctx = WebContextFactory.get(); 
		HttpSession session=ctx.getSession(); 
		Student student=(Student)session.getAttribute("user");
		student.setUpwd(userPwNew);
		studentService.updateStudent(student);
		session.setAttribute("user", student);
		
		return "yes";
    }
   
    public String userLogout()
    {
    	try 
		{
			Thread.sleep(700);
		} 
		catch (InterruptedException e)
		{
			e.printStackTrace();
		}
		WebContext ctx = WebContextFactory.get(); 
		HttpSession session=ctx.getSession(); 
		 
		session.setAttribute("userType", null);
        session.setAttribute("user", null);
		
		return "yes";
    }
    
}
