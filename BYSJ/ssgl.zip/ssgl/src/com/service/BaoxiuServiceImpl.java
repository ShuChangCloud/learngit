package com.service;
import java.util.List;
import com.model.Baoxiu;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.Map;
import com.mapper.BaoxiuMapper;
@Service
public class BaoxiuServiceImpl implements BaoxiuService
{
        
        @Autowired
	private BaoxiuMapper baoxiuMapper;


	public List<Baoxiu> queryBaoxiuList(Baoxiu baoxiu) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		if(baoxiu!=null){
			 map.put("sid", baoxiu.getSid());
		}
		
		List<Baoxiu> getBaoxiu = baoxiuMapper.query(map);
		return getBaoxiu;
	}

	public int insertBaoxiu(Baoxiu baoxiu) throws Exception {
		
		return baoxiuMapper.insertBaoxiu(baoxiu);
	}

	public int deleteBaoxiu(int id) throws Exception {
		return baoxiuMapper.deleteBaoxiu(id);
	}

	public int updateBaoxiu(Baoxiu baoxiu) throws Exception {
		return baoxiuMapper.updateBaoxiu(baoxiu);
	}
	
	public Baoxiu queryBaoxiuById(int id) throws Exception {
		return baoxiuMapper.queryBaoxiuById(id);
	}
 
}
