package com.service;
import java.util.List;
import java.util.Map;

import com.model.Shuifei;

public interface ShuifeiService
{
        public List<Shuifei> queryShuifeiList(Shuifei shuifei) throws Exception;
 
	public int insertShuifei(Shuifei shuifei) throws Exception ;
	
	public int deleteShuifei(int id) throws Exception ;
	
	public int updateShuifei(Shuifei shuifei) throws Exception ;
	
	public Shuifei queryShuifeiById(int id) throws Exception ;
	public List<Shuifei> reportFee(Shuifei shuifei);
}
