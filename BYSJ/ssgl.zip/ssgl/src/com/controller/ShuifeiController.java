package com.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.model.Shuifei;
import com.model.Student;
import com.model.Sushe;
import com.model.Sushelou;
import com.service.ShuifeiService;
import com.service.SusheService;
import com.service.SushelouService;
@Controller
public class ShuifeiController
{
       
    private double dianjia = 1; //���
    private double suijia = 1.5;//ˮ��
    @Autowired
	private ShuifeiService shuifeiService;
    @Autowired
	private SusheService susheService;
    @Autowired
    private SushelouService sushelouService;
 
	@RequestMapping(value="/shuifeiList")
	public String shuifeiList(HttpServletRequest request) throws Exception
	{
		Shuifei shuifei = new Shuifei();
		int userType = Integer.parseInt(request.getSession().getAttribute("userType")+"");
		if(userType==2){
			Student stu = (Student) request.getSession().getAttribute("user");
			shuifei.setSusheid(stu.getSusheid());
		}
		List<Shuifei> shuifeiList=shuifeiService.queryShuifeiList(shuifei);
		if(shuifeiList!=null && shuifeiList.size()>0){
			for (Shuifei shuifei2 : shuifeiList) {
				Sushe sushe = susheService.querySusheById(shuifei2.getSusheid().intValue());
				sushe.setSsl(sushelouService.querySushelouById(sushe.getSushelouid().intValue()));
				shuifei2.setSushe(sushe);
			}
		}
		request.setAttribute("shuifeiList", shuifeiList);
		return "/admin/shuifei/shuifei_list.jsp";
	}
	
	@RequestMapping(value="/shuifeiReport")
	public String shuifeiReport(HttpServletRequest request) throws Exception
	{
		List<Shuifei> shuifeiList=shuifeiService.reportFee(new Shuifei());
		request.setAttribute("shuifeiList", shuifeiList);
		return "/admin/shuifei/shuifei_report.jsp";
	}
	
	@RequestMapping(value="/toaddShuifei")
	public String toaddShuifei(HttpServletRequest request) throws Exception
	{
		Sushe sushe = new Sushe();
		List<Sushe> susheList=susheService.querySusheList(sushe);
		if(susheList!=null && susheList.size()>0){
			for (Sushe sushe2 : susheList) {
				sushe2.setSsl(sushelouService.querySushelouById(sushe2.getSushelouid().intValue()));
			}
		}
		request.setAttribute("susheList", susheList);
		return "/admin/shuifei/shuifei_add.jsp";
	}
	
 
	@RequestMapping(value="/shuifeiAdd")
	public String shuifeiAdd(Shuifei shuifei,HttpServletRequest request) throws Exception
	{
		int userType = Integer.parseInt(request.getSession().getAttribute("userType")+"");
		if(userType==2){
			Student stu = (Student) request.getSession().getAttribute("user");
			shuifei.setSusheid(stu.getSusheid());
			Sushe sushe  = susheService.querySusheById(stu.getSusheid().intValue());
			Sushelou sushelou = sushelouService.querySushelouById(sushe.getSushelouid().intValue());
			shuifei.setSusheadmin(sushelou.getMid());
		}
		shuifei.setDfee(shuifei.getDnums()*dianjia);
		shuifei.setFee(shuifei.getNums()*suijia);
	    shuifeiService.insertShuifei(shuifei);
		request.setAttribute("message","�����ɹ�");
		request.setAttribute("path","shuifeiList.action");
		return "common/succeed.jsp";
	}
	@RequestMapping(value="/shuifeiDel")
	public String shuifeiDel(HttpServletRequest request) throws Exception
	{
		int id = Integer.parseInt(request.getParameter("id"));
		 
		shuifeiService.deleteShuifei(id);
		request.setAttribute("message","�����ɹ�");
		request.setAttribute("path","shuifeiList.action");
		 
		return "common/succeed.jsp";
	}
	
	@RequestMapping(value="/shuifeiEditPre")
	public String shuifeiEditPre(HttpServletRequest request) throws Exception
	{
		int id = Integer.parseInt(request.getParameter("id"));
		Shuifei shuifei=shuifeiService.queryShuifeiById(id);
	    request.setAttribute("shuifei", shuifei);
	    
		Sushe sushe = new Sushe();
		List<Sushe> susheList=susheService.querySusheList(sushe);
		if(susheList!=null && susheList.size()>0){
			for (Sushe sushe2 : susheList) {
				sushe2.setSsl(sushelouService.querySushelouById(sushe2.getSushelouid().intValue()));
			}
		}
		request.setAttribute("susheList", susheList);
		
		return "/admin/shuifei/shuifei_edit.jsp";
	}
	
	@RequestMapping(value="/shuifeiView")
	public String shuifeiView(HttpServletRequest request) throws Exception
	{
		int id = Integer.parseInt(request.getParameter("id"));
		Shuifei shuifei=shuifeiService.queryShuifeiById(id);
		Sushe sushe  = susheService.querySusheById(shuifei.getSusheid().intValue());
		Sushelou sushelou = sushelouService.querySushelouById(sushe.getSushelouid().intValue());
		shuifei.setSusheadmin(sushelou.getMid());
		sushe.setSsl(sushelou);
		shuifei.setSushe(sushe);
	    request.setAttribute("shuifei", shuifei);
		return "/admin/shuifei/shuifei_view.jsp";
	}
	
	@RequestMapping(value="/shuifeiEdit")
	public String shuifeiEdit(Shuifei shuifei,HttpServletRequest request) throws Exception
	{
		shuifei.setDfee(shuifei.getDnums()*dianjia);
		shuifei.setFee(shuifei.getNums()*suijia);
		shuifeiService.updateShuifei(shuifei);
		request.setAttribute("message","�����ɹ�");
		request.setAttribute("path","shuifeiList.action");
		return "common/succeed.jsp";
	}

 


}
