package com.controller;

import com.model.Baoxiu;
import com.model.Student;
import com.model.Sushe;
import com.service.BaoxiuService;
import com.service.SusheService;
import com.service.SushelouService;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class BaoxiuController
{
       

    @Autowired
	private BaoxiuService baoxiuService;
    @Autowired
	private SusheService susheService;
    @Autowired
	private SushelouService sushelouService;
	@RequestMapping(value="/baoxiuList")
	public String baoxiuList(HttpServletRequest request) throws Exception
	{
		Baoxiu baoxiu = new Baoxiu();
		int userType = Integer.parseInt(request.getSession().getAttribute("userType")+"");
		if(userType==2){
			Student stu = (Student) request.getSession().getAttribute("user");
			baoxiu.setSid(stu.getId());
		}
		List<Baoxiu> baoxiuList=baoxiuService.queryBaoxiuList(baoxiu);
		if(baoxiuList!=null && baoxiuList.size()>0){
			for (Baoxiu baoxiu2 : baoxiuList) {
				Sushe sushe = susheService.querySusheById(baoxiu2.getSusheid().intValue());
				sushe.setSsl(sushelouService.querySushelouById(sushe.getSushelouid().intValue()));
				baoxiu2.setSushe(sushe);
			}
		}
		request.setAttribute("baoxiuList", baoxiuList);
		return "/admin/baoxiu/baoxiu_list.jsp";
	}
 
	@RequestMapping(value="/baoxiuAdd")
	public String baoxiuAdd(Baoxiu baoxiu,HttpServletRequest request) throws Exception
	{
		int userType = Integer.parseInt(request.getSession().getAttribute("userType")+"");
		if(userType==2){
			Student stu = (Student) request.getSession().getAttribute("user");
			baoxiu.setSusheid(stu.getSusheid());
			baoxiu.setSid(stu.getId());
			baoxiu.setBxsj(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
		}
	    baoxiuService.insertBaoxiu(baoxiu);
		request.setAttribute("message","�����ɹ�");
		request.setAttribute("path","baoxiuList.action");
		return "common/succeed.jsp";
	}
	@RequestMapping(value="/baoxiuDel")
	public String baoxiuDel(HttpServletRequest request) throws Exception
	{
		int id = Integer.parseInt(request.getParameter("id"));
		 
		baoxiuService.deleteBaoxiu(id);
		request.setAttribute("message","�����ɹ�");
		request.setAttribute("path","baoxiuList.action");
		 
		return "common/succeed.jsp";
	}
	
	@RequestMapping(value="/baoxiuEditPre")
	public String baoxiuEditPre(HttpServletRequest request) throws Exception
	{
		int id = Integer.parseInt(request.getParameter("id"));
		Baoxiu baoxiu=baoxiuService.queryBaoxiuById(id);
	    request.setAttribute("baoxiu", baoxiu);
		return "/admin/baoxiu/baoxiu_edit.jsp";
	}
	
	@RequestMapping(value="/baoxiuEdit")
	public String baoxiuEdit(Baoxiu baoxiu,HttpServletRequest request) throws Exception
	{
		baoxiu.setClsj(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
		baoxiuService.updateBaoxiu(baoxiu);
		request.setAttribute("message","�����ɹ�");
		request.setAttribute("path","baoxiuList.action");
		return "common/succeed.jsp";
	}

 


}
