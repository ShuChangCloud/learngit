package com.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.model.Sushelou;
import com.service.SushelouService;
@Controller
public class SushelouController
{
       

    @Autowired
	private SushelouService sushelouService;
 
	@RequestMapping(value="/sushelouList")
	public String sushelouList(HttpServletRequest request) throws Exception
	{
		Sushelou sushelou = new Sushelou();
		List<Sushelou> sushelouList=sushelouService.querySushelouList(sushelou);
		request.setAttribute("sushelouList", sushelouList);
		return "/admin/sushelou/sushelou_list.jsp";
	}
 
	@RequestMapping(value="/sushelouAdd")
	public String sushelouAdd(Sushelou sushelou,HttpServletRequest request) throws Exception
	{
	    sushelouService.insertSushelou(sushelou);
		request.setAttribute("message","�����ɹ�");
		request.setAttribute("path","sushelouList.action");
		return "common/succeed.jsp";
	}
	@RequestMapping(value="/sushelouDel")
	public String sushelouDel(HttpServletRequest request) throws Exception
	{
		int id = Integer.parseInt(request.getParameter("id"));
		 
		sushelouService.deleteSushelou(id);
		request.setAttribute("message","�����ɹ�");
		request.setAttribute("path","sushelouList.action");
		 
		return "common/succeed.jsp";
	}
	
	@RequestMapping(value="/sushelouEditPre")
	public String sushelouEditPre(HttpServletRequest request) throws Exception
	{
		int id = Integer.parseInt(request.getParameter("id"));
		Sushelou sushelou=sushelouService.querySushelouById(id);
	    request.setAttribute("sushelou", sushelou);
		return "/admin/sushelou/sushelou_edit.jsp";
	}
	
	@RequestMapping(value="/sushelouEdit")
	public String sushelouEdit(Sushelou sushelou,HttpServletRequest request) throws Exception
	{
		sushelouService.updateSushelou(sushelou);
		request.setAttribute("message","�����ɹ�");
		request.setAttribute("path","sushelouList.action");
		return "common/succeed.jsp";
	}

 


}
