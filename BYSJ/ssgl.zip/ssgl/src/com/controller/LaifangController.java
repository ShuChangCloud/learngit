package com.controller;

import com.model.Laifang;
import com.service.LaifangService;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class LaifangController
{
       

   @Autowired
	private LaifangService laifangService;
	 
 
	@RequestMapping(value="/laifangList")
	public String laifangList(HttpServletRequest request) throws Exception
	{
		Laifang laifang = new Laifang();
		List laifangList=laifangService.queryLaifangList(laifang);
		request.setAttribute("laifangList", laifangList);
		return "/admin/laifang/laifang_list.jsp";
	}
 
	@RequestMapping(value="/laifangAdd")
	public String laifangAdd(Laifang laifang,HttpServletRequest request) throws Exception
	{
		laifang.setLfsj(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
	    laifangService.insertLaifang(laifang);
		request.setAttribute("message","�����ɹ�");
		request.setAttribute("path","laifangList.action");
		return "common/succeed.jsp";
	}
	@RequestMapping(value="/laifangDel")
	public String laifangDel(HttpServletRequest request) throws Exception
	{
		int id = Integer.parseInt(request.getParameter("id"));
		 
		laifangService.deleteLaifang(id);
		request.setAttribute("message","�����ɹ�");
		request.setAttribute("path","laifangList.action");
		 
		return "common/succeed.jsp";
	}
	
	@RequestMapping(value="/laifangEditPre")
	public String laifangEditPre(HttpServletRequest request) throws Exception
	{
		int id = Integer.parseInt(request.getParameter("id"));
		Laifang laifang=laifangService.queryLaifangById(id);
	    request.setAttribute("laifang", laifang);
		return "/admin/laifang/laifang_edit.jsp";
	}
	
	@RequestMapping(value="/laifangEdit")
	public String laifangEdit(Laifang laifang,HttpServletRequest request) throws Exception
	{
		laifangService.updateLaifang(laifang);
		request.setAttribute("message","�����ɹ�");
		request.setAttribute("path","laifangList.action");
		return "common/succeed.jsp";
	}

 


}
