package com.controller;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.model.Student;
import com.model.Sushe;
import com.service.StudentService;
import com.service.SusheService;
import com.service.SushelouService;
@Controller
public class StudentController
{
       
	private POIFSFileSystem fs;
  	private HSSFWorkbook wb;
  	private HSSFSheet sheet;
  	private HSSFRow row;
  	
    @Autowired
	private StudentService studentService;
    @Autowired
	private SusheService susheService;
    @Autowired
    private SushelouService sushelouService;
	@RequestMapping(value="/studentList")
	public String studentList(HttpServletRequest request) throws Exception
	{
		Student student = new Student();
		student.setState("��У");
		List<Student> studentList=studentService.queryStudentList(student);
		if(studentList!=null && studentList.size()>0){
			for (Student stu : studentList) {
				if(stu.getSusheid()!=null && stu.getSusheid()!=0){
					Sushe sushe = susheService.querySusheById(stu.getSusheid().intValue());
					sushe.setSsl(sushelouService.querySushelouById(sushe.getSushelouid().intValue()));
					stu.setSushe(sushe);
				}
			
			}
		}
		request.setAttribute("studentList", studentList);
		return "/admin/student/student_list.jsp";
	}
 
	@RequestMapping(value="/studentLxList")
	public String studentLxList(HttpServletRequest request) throws Exception
	{
		Student student = new Student();
		student.setState("��У");
		List<Student> studentList=studentService.queryStudentList(student);
		if(studentList!=null && studentList.size()>0){
			for (Student stu : studentList) {
				if(stu.getSusheid()!=null && stu.getSusheid()!=0){
					Sushe sushe = susheService.querySusheById(stu.getSusheid().intValue());
					sushe.setSsl(sushelouService.querySushelouById(sushe.getSushelouid().intValue()));
					stu.setSushe(sushe);
				}
			
			}
		}
		request.setAttribute("studentList", studentList);
		return "/admin/student/student_lxlist.jsp";
	}
 
	
	@RequestMapping(value="/studentAdd")
	public String studentAdd(Student student,HttpServletRequest request) throws Exception
	{
		student.setState("��У");
	    studentService.insertStudent(student);
		request.setAttribute("message","�����ɹ�");
		request.setAttribute("path","studentList.action");
		return "common/succeed.jsp";
	}
	@RequestMapping(value="/studentDel")
	public String studentDel(HttpServletRequest request) throws Exception
	{
		int id = Integer.parseInt(request.getParameter("id"));
		 
		studentService.deleteStudent(id);
		request.setAttribute("message","�����ɹ�");
		request.setAttribute("path","studentList.action");
		 
		return "common/succeed.jsp";
	}
	
	@RequestMapping(value="/studentLxDel")
	public String studentLxDel(HttpServletRequest request) throws Exception
	{
		int id = Integer.parseInt(request.getParameter("id"));
		 
		studentService.deleteStudent(id);
		request.setAttribute("message","�����ɹ�");
		request.setAttribute("path","studentLxList.action");
		 
		return "common/succeed.jsp";
	}
	
	
	
	
	@RequestMapping(value="/studentEditPre")
	public String studentEditPre(HttpServletRequest request) throws Exception
	{
		int id = Integer.parseInt(request.getParameter("id"));
		Student student=studentService.queryStudentById(id);
	    request.setAttribute("student", student);
		return "/admin/student/student_edit.jsp";
	}
	
	@RequestMapping(value="/studentEdit")
	public String studentEdit(Student student,HttpServletRequest request) throws Exception
	{
		studentService.updateStudent(student);
		request.setAttribute("message","�����ɹ�");
		request.setAttribute("path","studentList.action");
		return "common/succeed.jsp";
	}
	
	
	@RequestMapping(value="/studentUpdate")
	public String studentUpdate(Student student,HttpServletRequest request) throws Exception
	{
		studentService.updateStudent(student);
		request.setAttribute("message","�����ɹ�");
		request.setAttribute("path","admin/student/student_info.jsp");
		return "common/succeed.jsp";
	}
	
	
	@RequestMapping(value="/studentLx")
	public String studentLx(HttpServletRequest request) throws Exception
	{
		int id = Integer.parseInt(request.getParameter("id"));
		Student student=studentService.queryStudentById(id);
		student.setState("��У");
		if(student.getSusheid()!=null && student.getSusheid()!=0){
			Sushe sushe = susheService.querySusheById(student.getSusheid().intValue());
			long xjrs = sushe.getXjrs()-1<=0?0: sushe.getXjrs()-1;
			sushe.setXjrs(xjrs);
			susheService.updateSushe(sushe);
		}
		studentService.updateStudent(student);
		request.setAttribute("message","�����ɹ�");
		request.setAttribute("path","studentList.action");
		return "common/succeed.jsp";
	}
	
	@RequestMapping(value="/studentRegister")
	public String studentRegister(Student student,HttpServletRequest request) throws Exception
	{
		Student stu  = new Student();
		stu.setSno(student.getSno());
		List<Student> slist = studentService.queryStudentList(stu);
		if(slist!=null && slist.size()>0){
			Student st = slist.get(0);
			st.setSno(student.getSno());
			st.setUpwd(student.getUpwd());
			studentService.updateStudent(st);
			request.setAttribute("message","ע��ɹ�");
			request.setAttribute("path","qiantai/login.jsp");
		}else{
			request.setAttribute("message","��������ȷ��ѧ��");
			request.setAttribute("path","qiantai/register.jsp");
		}
		return "common/succeed.jsp";
	}
	
	/**
	 * ��������
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/fenPeiSushe")
	public String fenPeiSushe(HttpServletRequest request) throws Exception
	{
		Student stu = new Student();
		stu.setSex("��");
		stu.setWfp("δ����");
		List<Student> studentList=studentService.queryStudentList(stu);
		Sushe shuse = new Sushe();
		shuse.setSex("��");
		List<Sushe> slist = susheService.querySushe(shuse);
		fenpei(studentList,slist);
	 
		
		stu = new Student();
		stu.setSex("Ů");
		stu.setWfp("δ����");
		List<Student> studentnList=studentService.queryStudentList(stu);
		shuse = new Sushe();
		shuse.setSex("Ů");
		List<Sushe> snlist = susheService.querySushe(shuse);
		fenpei(studentnList,snlist);
		return "studentList.action";
	}
	
	
	public void fenpei(List<Student> studentList,List<Sushe> slist)  throws Exception{
		if(slist!=null && slist.size()>0){
			if(studentList!=null && studentList.size()>0){
				for (Sushe sushe : slist) {
					int rnrs = sushe.getRnrs().intValue();
					int xyrz = sushe.getXjrs().intValue();
					int rz = rnrs - xyrz;//������ס����
					if(rz>0){
						for (int i = 0; i < rz; i++) {
							int index = studentList.size()-1;
							if(index>=0){
								Student stud = studentList.get(index);
								stud.setSusheid(sushe.getId());
								sushe.setXjrs(sushe.getXjrs()+1);
								System.out.println("����ѧ��" + stud.getSusheid());
								System.out.println(sushe.getId() + "��������" + sushe.getXjrs());
								studentService.updateStudent(stud);
								susheService.updateSushe(sushe);
								studentList.remove(index);
							}
						}
					}
				}
				 
			} 
		}
	}
	
	
	/**
	 * ѧ��Excel����
	 * @param request
	 * @param file
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/studentImport")
	public String studentImport(HttpServletRequest request,@RequestParam("file") CommonsMultipartFile file) throws Exception
	{
		 InputStream is=file.getInputStream();
		 readExcelContent(is);
		 if(is!=null){
			 is.close();
		 }
		 return "studentList.action";
	}
	
	/**
	 * ��ȡExcel����
	 * @param is
	 * @param teacher
	 * @throws Exception
	 */
	public void readExcelContent(InputStream is)  throws Exception {
		
		try {
			fs = new POIFSFileSystem(is);
			wb = new HSSFWorkbook(fs);
		} catch (IOException e) {
			e.printStackTrace();
		}
		sheet = wb.getSheetAt(0);
		// �õ�������
		int rowNum = sheet.getLastRowNum();
		row = sheet.getRow(0);
		// ��������Ӧ�ôӵڶ��п�ʼ,��һ��Ϊ��ͷ�ı���
		for (int i = 2; i <= rowNum; i++) {
			
			row = sheet.getRow(i); //��ȡExcel�еĵ�i��
			if (row != null) {
				String sno = getStringCellValue(row.getCell((short) 0));//��ȡѧ��
				String name = getStringCellValue(row.getCell((short) 1));//��ȡ����
				String sex = getStringCellValue(row.getCell((short) 2));//��ȡ�Ա�
				String banji = getStringCellValue(row.getCell((short) 3));//��ȡ�༶
				String yuanxi = getStringCellValue(row.getCell((short) 4));//��ȡԺϵ
				String rxnf = getStringCellValue(row.getCell((short) 5));//��ȡ��ѧ���
				String tel = getStringCellValue(row.getCell((short) 6));//��ȡ��ϵ�绰
				String ftel = getStringCellValue(row.getCell((short) 7));//��ȡ�ҳ���ϵ�绰
				String upwd = "123456";
				if(sno == null || "".equals(sno)){
					continue;
				}
				Student student = new Student();
				student.setSno(sno);
				List<Student> list = studentService.queryStudentList(student);
				if(list!=null && list.size()>0){
					student = list.get(0);
					student.setName(name);
					student.setSex(sex);
					student.setBanji(Long.valueOf(banji));
					student.setYuanxi(yuanxi);
					student.setRxnf(rxnf);
					student.setMtel(tel);
					student.setFtel(ftel);
					student.setUpwd(upwd);
					studentService.updateStudent(student);
				}else{
					student.setName(name);
					student.setSex(sex);
					student.setBanji(Long.valueOf(banji));
					student.setYuanxi(yuanxi);
					student.setRxnf(rxnf);
					student.setMtel(tel);
					student.setFtel(ftel);
					student.setUpwd(upwd);
					student.setState("��У");
					studentService.insertStudent(student);
				}
			}
		}
	}

	/**
	 * ��ȡ��Ԫ����������Ϊ�ַ������͵�����
	 * 
	 * @param cell
	 *            Excel��Ԫ��
	 * @return String ��Ԫ����������
	 */
	private String getStringCellValue(HSSFCell cell) {
		cell.setCellType(Cell.CELL_TYPE_STRING);
		if (cell == null) {
			return "";
		}
		String strCell = "";
		strCell = cell.getStringCellValue();
		if (strCell.equals("") || strCell == null) {
			return "";
		}
		if (cell == null) {
			return "";
		}
		return strCell;
	}
	
 


}
