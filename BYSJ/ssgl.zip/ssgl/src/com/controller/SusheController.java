package com.controller;

import com.model.Sushe;
import com.model.Sushelou;
import com.service.SusheService;
import com.service.SushelouService;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class SusheController
{
       

    @Autowired
	private SusheService susheService;
    
    @Autowired
    private SushelouService sushelouService;
	 
 
	@RequestMapping(value="/susheList")
	public String susheList(HttpServletRequest request) throws Exception
	{
		Sushe sushe = new Sushe();
		List<Sushe> susheList=susheService.querySusheList(sushe);
		if(susheList!=null && susheList.size()>0){
			for (Sushe sushe2 : susheList) {
				sushe2.setSsl(sushelouService.querySushelouById(sushe2.getSushelouid().intValue()));
			}
		}
		request.setAttribute("susheList", susheList);
		return "/admin/sushe/sushe_list.jsp";
	}
 
	
	@RequestMapping(value="/tosusheAdd")
	public String tosusheAdd(HttpServletRequest request) throws Exception
	{
		List<Sushelou> sushelouList=sushelouService.querySushelouList(new Sushelou());
		request.setAttribute("sushelouList", sushelouList);
		return "/admin/sushe/sushe_add.jsp";
	}
	
	@RequestMapping(value="/susheAdd")
	public String susheAdd(Sushe sushe,HttpServletRequest request) throws Exception
	{
	    susheService.insertSushe(sushe);
		request.setAttribute("message","�����ɹ�");
		request.setAttribute("path","susheList.action");
		return "common/succeed.jsp";
	}
	@RequestMapping(value="/susheDel")
	public String susheDel(HttpServletRequest request) throws Exception
	{
		int id = Integer.parseInt(request.getParameter("id"));
		susheService.deleteSushe(id);
		request.setAttribute("message","�����ɹ�");
		request.setAttribute("path","susheList.action");
		return "common/succeed.jsp";
	}
	
	@RequestMapping(value="/susheEditPre")
	public String susheEditPre(HttpServletRequest request) throws Exception
	{
		int id = Integer.parseInt(request.getParameter("id"));
		Sushe sushe=susheService.querySusheById(id);
		List<Sushelou> sushelouList=sushelouService.querySushelouList(new Sushelou());
		request.setAttribute("sushelouList", sushelouList);
	    request.setAttribute("sushe", sushe);
		return "/admin/sushe/sushe_edit.jsp";
	}
	
	@RequestMapping(value="/susheEdit")
	public String susheEdit(Sushe sushe,HttpServletRequest request) throws Exception
	{
		susheService.updateSushe(sushe);
		request.setAttribute("message","�����ɹ�");
		request.setAttribute("path","susheList.action");
		return "common/succeed.jsp";
	}

 


}
