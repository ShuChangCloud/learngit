package com.controller;

import com.model.Banji;
import com.service.BanjiService;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class BanjiController
{
       

   @Autowired
	private BanjiService banjiService;
	 
 
	@RequestMapping(value="/banjiList")
	public String banjiList(HttpServletRequest request) throws Exception
	{
		Banji banji = new Banji();
		String nianji = request.getParameter("nianji");
		List banjiList=banjiService.queryBanjiList(banji);
		request.setAttribute("banjiList", banjiList);
		request.setAttribute("nianji", nianji);
		return "/admin/banji/banji_list.jsp";
	}
 
	@RequestMapping(value="/banjiAdd")
	public String banjiAdd(Banji banji,HttpServletRequest request) throws Exception
	{
	    banjiService.insertBanji(banji);
		request.setAttribute("message","�����ɹ�");
		request.setAttribute("path","banjiList.action");
		return "common/succeed.jsp";
	}
	@RequestMapping(value="/banjiDel")
	public String banjiDel(HttpServletRequest request) throws Exception
	{
		int id = Integer.parseInt(request.getParameter("id"));
		 
		banjiService.deleteBanji(id);
		request.setAttribute("message","�����ɹ�");
		request.setAttribute("path","banjiList.action");
		 
		return "common/succeed.jsp";
	}
	
	@RequestMapping(value="/banjiEditPre")
	public String banjiEditPre(HttpServletRequest request) throws Exception
	{
		int id = Integer.parseInt(request.getParameter("id"));
		Banji banji=banjiService.queryBanjiById(id);
	    request.setAttribute("banji", banji);
		return "/admin/banji/banji_edit.jsp";
	}
	
	@RequestMapping(value="/banjiEdit")
	public String banjiEdit(Banji banji,HttpServletRequest request) throws Exception
	{
		banjiService.updateBanji(banji);
		request.setAttribute("message","�����ɹ�");
		request.setAttribute("path","banjiList.action");
		return "common/succeed.jsp";
	}

 


}
