package com.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import com.model.TAdmin;
import com.service.TAdminService;

 
@Controller
public class AdminController {
	@Autowired
	private TAdminService tAdminService;
	
	@RequestMapping(value="/adminAdd")
	public String adminAdd(TAdmin admin,HttpServletRequest request) throws Exception
	{
		TAdmin query = new TAdmin();
		query.setUname(admin.getUname());
		List list = tAdminService.queryTAdminList(query);
		if(list!=null && list.size()>0)
		{
			request.setAttribute("message","�˻��Ѵ���");
			request.setAttribute("path","admin/admin/adminAdd.jsp");
			return "common/succeed.jsp";
		}
		else
		{
			tAdminService.insertTAdmin(admin);
			request.setAttribute("message","�����ɹ�");
			request.setAttribute("path","adminManage.action");
			return "common/succeed.jsp";
		}
		
		
	}
	
	
	@RequestMapping(value="/adminManage")
	public String adminManage(HttpServletRequest request)
	{
		List adminList;
		try {
			adminList = tAdminService.queryTAdminList(new TAdmin());
			request.setAttribute("adminList", adminList);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "admin/admin/adminMana.jsp";
	}
	
	
	@RequestMapping(value="/adminDel")
	public String adminDel(HttpServletRequest request)
	{
		int userId = Integer.parseInt(request.getParameter("id"));
		try {
			tAdminService.deleteTAdmin(userId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		request.setAttribute("message","ɾ���ɹ�");
		request.setAttribute("path","adminManage.action");
	 
		return "common/succeed.jsp";
	}
	
	 
	
}
