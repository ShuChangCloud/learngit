package com.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.model.Gonggao;
import com.service.GonggaoService;
@Controller
public class GonggaoController
{
       
	int PAGE_IETM = 10;  //ÿҳ����
    @Autowired
	private GonggaoService gonggaoService;
	 
 
	@RequestMapping(value="/gonggaoList")
	public String gonggaoList(HttpServletRequest request) throws Exception
	{
		
		int offset = 0;  //��¼ƫ����
		int count = 0;  //�ܼ�¼��
		try {
			offset = Integer.parseInt(request.getParameter("pager.offset"));
		} catch (Exception e) {
		}
		Gonggao gonggao = new Gonggao();
		String title = request.getParameter("title");
		gonggao.setTitle(title);
		int counts =  gonggaoService.queryGonggaoList(gonggao).size();
		gonggao.setOffset(offset);
		gonggao.setPagesize(PAGE_IETM);
		List gonggaoList=gonggaoService.queryGonggaoList(gonggao);
		request.setAttribute("gonggaoList", gonggaoList);
		request.setAttribute("title", title);
		request.setAttribute("itemSize",counts);
		int page_count = counts % PAGE_IETM == 0 ? counts / PAGE_IETM : counts / PAGE_IETM + 1;
		request.setAttribute("pageItem",PAGE_IETM);
		request.setAttribute("pageTotal",page_count);
		return "/admin/gonggao/gonggao_list.jsp";
	}
 
	@RequestMapping(value="/gonggaoAdd")
	public String gonggaoAdd(Gonggao gonggao,HttpServletRequest request) throws Exception
	{
		gonggao.setFbsj(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
	    gonggaoService.insertGonggao(gonggao);
		request.setAttribute("message","�����ɹ�");
		request.setAttribute("path","gonggaoList.action");
		return "common/succeed.jsp";
	}
	@RequestMapping(value="/gonggaoDel")
	public String gonggaoDel(HttpServletRequest request) throws Exception
	{
		int id = Integer.parseInt(request.getParameter("id"));
		 
		gonggaoService.deleteGonggao(id);
		request.setAttribute("message","�����ɹ�");
		request.setAttribute("path","gonggaoList.action");
		 
		return "common/succeed.jsp";
	}
	
	@RequestMapping(value="/gonggaoEditPre")
	public String gonggaoEditPre(HttpServletRequest request) throws Exception
	{
		int id = Integer.parseInt(request.getParameter("id"));
		Gonggao gonggao=gonggaoService.queryGonggaoById(id);
	    request.setAttribute("gonggao", gonggao);
		return "/admin/gonggao/gonggao_edit.jsp";
	}
	
	@RequestMapping(value="/gonggaoEdit")
	public String gonggaoEdit(Gonggao gonggao,HttpServletRequest request) throws Exception
	{
		gonggaoService.updateGonggao(gonggao);
		request.setAttribute("message","�����ɹ�");
		request.setAttribute("path","gonggaoList.action");
		return "common/succeed.jsp";
	}

	@RequestMapping(value="/gonggaoView")
	public String gonggaoView(HttpServletRequest request) throws Exception
	{
		int id = Integer.parseInt(request.getParameter("id"));
		Gonggao gonggao=gonggaoService.queryGonggaoById(id);
	    request.setAttribute("gonggao", gonggao);
		return "/admin/gonggao/gonggao_view.jsp";
	}
	
	@RequestMapping(value="/gonggaoDetail")
	public String gonggaoDetail(HttpServletRequest request) throws Exception
	{
		int id = Integer.parseInt(request.getParameter("id"));
		Gonggao gonggao=gonggaoService.queryGonggaoById(id);
	    request.setAttribute("info", gonggao);
		return "/qiantai/contentdetail.jsp";
	}


}
