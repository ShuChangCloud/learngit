package com.model;
public class Student
{
 
	public Student(){
  
	}
	 
	private Long id;
        
         
	private String sno;
        
         
	private String name;
        
         
	private String sex;
        
         
	private String rxnf;
        
         
	private Long banji;
        
	private String yuanxi;
	
    private String state;
 
	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Long getBanji() {
		return banji;
	}

	public void setBanji(Long banji) {
		this.banji = banji;
	}
    private Sushe sushe;
	private String mtel;
        
         
	private String ftel;
        
         
	private Long susheid;
        
         
	private String upwd;
        
    private String wfp;
    
         
	public Sushe getSushe() {
		return sushe;
	}

	public void setSushe(Sushe sushe) {
		this.sushe = sushe;
	}

	public Long getId(){
		return this.id;
	}
 
	public void setId(Long id){
		this.id = id;
	}
		
         
	public String getSno(){
		return this.sno;
	}
 
	public void setSno(String sno){
		this.sno = sno;
	}
		
         
	public String getName(){
		return this.name;
	}
 
	public void setName(String name){
		this.name = name;
	}
		
         
	public String getSex(){
		return this.sex;
	}
 
	public void setSex(String sex){
		this.sex = sex;
	}

	public String getRxnf() {
		return rxnf;
	}

	public void setRxnf(String rxnf) {
		this.rxnf = rxnf;
	}

 
	public String getYuanxi() {
		return yuanxi;
	}

	public void setYuanxi(String yuanxi) {
		this.yuanxi = yuanxi;
	}

	public String getMtel() {
		return mtel;
	}

	public void setMtel(String mtel) {
		this.mtel = mtel;
	}

	public String getFtel() {
		return ftel;
	}

	public void setFtel(String ftel) {
		this.ftel = ftel;
	}

	public Long getSusheid() {
		return susheid;
	}

	public void setSusheid(Long susheid) {
		this.susheid = susheid;
	}

	public String getUpwd() {
		return upwd;
	}

	public void setUpwd(String upwd) {
		this.upwd = upwd;
	}

	public String getWfp() {
		return wfp;
	}

	public void setWfp(String wfp) {
		this.wfp = wfp;
	}
		
    
}
