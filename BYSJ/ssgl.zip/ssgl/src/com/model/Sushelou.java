package com.model;
public class Sushelou
{
 
	public Sushelou(){
  
	}
	 
	private Long id;
        
         
	private String name;
        
         
	private Long scount;
        
         
	private Long tnums;
        
         
	private Long mid;
    
 
	private String sex;
	
	
         
	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}
	

	public Long getId(){
		return this.id;
	}
 
	public void setId(Long id){
		this.id = id;
	}
		
         
	public String getName(){
		return this.name;
	}
 
	public void setName(String name){
		this.name = name;
	}
		
         
	public Long getScount(){
		return this.scount;
	}
 
	public void setScount(Long scount){
		this.scount = scount;
	}
		
         
	public Long getTnums(){
		return this.tnums;
	}
 
	public void setTnums(Long tnums){
		this.tnums = tnums;
	}
		
         
	public Long getMid(){
		return this.mid;
	}
 
	public void setMid(Long mid){
		this.mid = mid;
	}

	 
            
}
