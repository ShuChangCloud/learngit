package com.model;
public class Gonggao
{
 
	public Gonggao(){
  
	}
	 
	private Long id;
        
         
	private String title;
        
         
	private String contents;
        
         
	private String fbsj;
        
    private int offset;
    private int pagesize;
         
	public Long getId(){
		return this.id;
	}
 
	public void setId(Long id){
		this.id = id;
	}
		
         
	public String getTitle(){
		return this.title;
	}
 
	public void setTitle(String title){
		this.title = title;
	}
		
         
	public String getContents(){
		return this.contents;
	}
 
	public void setContents(String contents){
		this.contents = contents;
	}
		
         
	public String getFbsj(){
		return this.fbsj;
	}
 
	public void setFbsj(String fbsj){
		this.fbsj = fbsj;
	}

	public int getOffset() {
		return offset;
	}

	public void setOffset(int offset) {
		this.offset = offset;
	}

	public int getPagesize() {
		return pagesize;
	}

	public void setPagesize(int pagesize) {
		this.pagesize = pagesize;
	}
		
            
}
