package com.model;
public class Sushe
{
 
	public Sushe(){
  
	}
	 
	private Long id;
        
         
	private String name;
        
         
	private Long rnrs=0l;
        
         
	private Long xjrs=0l;
    
	private Long sushelouid;
    
	private Sushelou ssl;
    private String sex;
    
    
	
	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public Sushelou getSsl() {
		return ssl;
	}

	public void setSsl(Sushelou ssl) {
		this.ssl = ssl;
	}

	public Long getSushelouid() {
		return sushelouid;
	}

	public void setSushelouid(Long sushelouid) {
		this.sushelouid = sushelouid;
	}

	public Long getId(){
		return this.id;
	}
 
	public void setId(Long id){
		this.id = id;
	}
		
         
	public String getName(){
		return this.name;
	}
 
	public void setName(String name){
		this.name = name;
	}
		
         
	public Long getRnrs(){
		return this.rnrs;
	}
 
	public void setRnrs(Long rnrs){
		this.rnrs = rnrs;
	}
		
         
	public Long getXjrs(){
		return this.xjrs;
	}
 
	public void setXjrs(Long xjrs){
		this.xjrs = xjrs;
	}
		
            
}
