package com.model;
public class Baoxiu
{
 
	public Baoxiu(){
  
	}
	 
	private Long id;
        
         
	private Long susheid;
        
         
	private String bxinfo;
        
         
	private String bxsj;
        
         
	private String chuli;
        
         
	private String clsj;
        
         
	private String state;
        
         
	private Long sid;
        
    private Sushe sushe;
         
	public Sushe getSushe() {
		return sushe;
	}

	public void setSushe(Sushe sushe) {
		this.sushe = sushe;
	}

	public Long getId(){
		return this.id;
	}
 
	public void setId(Long id){
		this.id = id;
	}
		
         
	public Long getSusheid(){
		return this.susheid;
	}
 
	public void setSusheid(Long susheid){
		this.susheid = susheid;
	}
		
         
	public String getBxinfo(){
		return this.bxinfo;
	}
 
	public void setBxinfo(String bxinfo){
		this.bxinfo = bxinfo;
	}
		
         
	public String getBxsj(){
		return this.bxsj;
	}
 
	public void setBxsj(String bxsj){
		this.bxsj = bxsj;
	}
		
         
	public String getChuli(){
		return this.chuli;
	}
 
	public void setChuli(String chuli){
		this.chuli = chuli;
	}
		
         
	public String getClsj(){
		return this.clsj;
	}
 
	public void setClsj(String clsj){
		this.clsj = clsj;
	}
		
         
	public String getState(){
		return this.state;
	}
 
	public void setState(String state){
		this.state = state;
	}
		
         
	public Long getSid(){
		return this.sid;
	}
 
	public void setSid(Long sid){
		this.sid = sid;
	}
		
            
}
