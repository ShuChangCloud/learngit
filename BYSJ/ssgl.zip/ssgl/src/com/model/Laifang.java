package com.model;
public class Laifang
{
 
	public Laifang(){
  
	}
	 
	private Long id;
        
         
	private String name;
        
         
	private String idno;
        
         
	private String lfsj;
        
         
	private String remarks;
        
        
         
	public Long getId(){
		return this.id;
	}
 
	public void setId(Long id){
		this.id = id;
	}
		
         
	public String getName(){
		return this.name;
	}
 
	public void setName(String name){
		this.name = name;
	}
		
         
	public String getIdno(){
		return this.idno;
	}
 
	public void setIdno(String idno){
		this.idno = idno;
	}
		
         
	public String getLfsj(){
		return this.lfsj;
	}
 
	public void setLfsj(String lfsj){
		this.lfsj = lfsj;
	}
		
         
	public String getRemarks(){
		return this.remarks;
	}
 
	public void setRemarks(String remarks){
		this.remarks = remarks;
	}
		
            
}
