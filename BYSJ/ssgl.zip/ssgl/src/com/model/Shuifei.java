package com.model;
public class Shuifei
{
 
	public Shuifei(){
  
	}
	 
	private Long id;
        
         
	private Long susheid;
        
         
	private Long susheadmin;
        
         
	private String feemonth;
        
         
	private String fujian;
        
         
	private Double fee;
        
         
	private Long nums;
    
	private Sushe sushe;
    
	private Long dnums;
	
	private Double dfee;
         
	public Sushe getSushe() {
		return sushe;
	}

	public void setSushe(Sushe sushe) {
		this.sushe = sushe;
	}

	public Long getId(){
		return this.id;
	}
 
	public void setId(Long id){
		this.id = id;
	}
		
         
	public Long getSusheid(){
		return this.susheid;
	}
 
	public void setSusheid(Long susheid){
		this.susheid = susheid;
	}
		
         
	public Long getSusheadmin(){
		return this.susheadmin;
	}
 
	public void setSusheadmin(Long susheadmin){
		this.susheadmin = susheadmin;
	}
		
         
	public String getFeemonth(){
		return this.feemonth;
	}
 
	public void setFeemonth(String feemonth){
		this.feemonth = feemonth;
	}
		
         
	public String getFujian(){
		return this.fujian;
	}
 
	public void setFujian(String fujian){
		this.fujian = fujian;
	}
		
         
	public Double getFee(){
		return this.fee;
	}
 
	public void setFee(Double fee){
		this.fee = fee;
	}
		
         
	public Long getNums(){
		return this.nums;
	}
 
	public void setNums(Long nums){
		this.nums = nums;
	}

	public Long getDnums() {
		return dnums;
	}

	public void setDnums(Long dnums) {
		this.dnums = dnums;
	}

	public Double getDfee() {
		return dfee;
	}

	public void setDfee(Double dfee) {
		this.dfee = dfee;
	}
		
            
}
