package com.mapper;
import com.model.Laifang;
import java.util.List;
import java.util.Map;
public interface LaifangMapper
{

	public List<Laifang> findLaifangList();
	
	public List<Laifang> query(Map<String,Object> inputParam);
	
	public int insertLaifang(Laifang laifang);
	
	public int deleteLaifang(int id);
	
	public int updateLaifang(Laifang laifang);
	
	public Laifang queryLaifangById(int id);

}
