package com.mapper;
import com.model.Sushelou;
import java.util.List;
import java.util.Map;
public interface SushelouMapper
{

	public List<Sushelou> findSushelouList();
	
	public List<Sushelou> query(Map<String,Object> inputParam);
	
	public int insertSushelou(Sushelou sushelou);
	
	public int deleteSushelou(int id);
	
	public int updateSushelou(Sushelou sushelou);
	
	public Sushelou querySushelouById(int id);

}
