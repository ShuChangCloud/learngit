package com.mapper;
import com.model.Shuifei;
import java.util.List;
import java.util.Map;
public interface ShuifeiMapper
{

	public List<Shuifei> findShuifeiList();
	
	public List<Shuifei> query(Map<String,Object> inputParam);
	public List<Shuifei> reportFee(Map<String,Object> inputParam);
	
	public int insertShuifei(Shuifei shuifei);
	
	public int deleteShuifei(int id);
	
	public int updateShuifei(Shuifei shuifei);
	
	public Shuifei queryShuifeiById(int id);

}
