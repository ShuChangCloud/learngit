package com.mapper;
import com.model.Sushe;
import java.util.List;
import java.util.Map;
public interface SusheMapper
{

	public List<Sushe> findSusheList();
	
	public List<Sushe> query(Map<String,Object> inputParam);
	public List<Sushe> querySushe(Map<String,Object> inputParam);
	public int insertSushe(Sushe sushe);
	
	public int deleteSushe(int id);
	
	public int updateSushe(Sushe sushe);
	
	public Sushe querySusheById(int id);
	
}
