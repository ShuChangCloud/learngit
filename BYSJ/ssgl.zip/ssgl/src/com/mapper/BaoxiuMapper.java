package com.mapper;
import com.model.Baoxiu;
import java.util.List;
import java.util.Map;
public interface BaoxiuMapper
{

	public List<Baoxiu> findBaoxiuList();
	
	public List<Baoxiu> query(Map<String,Object> inputParam);
	
	public int insertBaoxiu(Baoxiu baoxiu);
	
	public int deleteBaoxiu(int id);
	
	public int updateBaoxiu(Baoxiu baoxiu);
	
	public Baoxiu queryBaoxiuById(int id);

}
