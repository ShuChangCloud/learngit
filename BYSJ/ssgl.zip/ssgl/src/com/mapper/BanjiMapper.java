package com.mapper;
import com.model.Banji;
import java.util.List;
import java.util.Map;
public interface BanjiMapper
{

	public List<Banji> findBanjiList();
	
	public List<Banji> query(Map<String,Object> inputParam);
	
	public int insertBanji(Banji banji);
	
	public int deleteBanji(int id);
	
	public int updateBanji(Banji banji);
	
	public Banji queryBanjiById(int id);

}
