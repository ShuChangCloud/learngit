package com.mapper;

import java.util.List;
import java.util.Map;

import com.model.TAdmin;

public interface TAdminMapper {
	public List<TAdmin> findTAdminList();
	
	public List<TAdmin> query(Map<String,Object> inputParam);
	
	public int insertTAdmin(TAdmin admin);
	
	public int deleteTAdmin(int id);
	
	public int updateTAdmin(TAdmin admin);
	
	public TAdmin queryTAdminById(int id);
	
 
	
	
}
