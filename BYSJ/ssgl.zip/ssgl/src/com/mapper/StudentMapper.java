package com.mapper;
import com.model.Student;
import java.util.List;
import java.util.Map;
public interface StudentMapper
{

	public List<Student> findStudentList();
	
	public List<Student> query(Map<String,Object> inputParam);
	
	public int insertStudent(Student student);
	
	public int deleteStudent(int id);
	
	public int updateStudent(Student student);
	
	public Student queryStudentById(int id);

}
