﻿# Host: 127.0.0.1  (Version 5.5.15)
# Date: 2018-03-06 16:13:48
# Generator: MySQL-Front 6.0  (Build 2.20)


#
# Structure for table "admin"
#
create database ssgl;
use ssgl;
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uname` varchar(50) DEFAULT NULL,
  `upwd` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='管理员信息表';

#
# Data for table "admin"
#

INSERT INTO `admin` VALUES (1,'admin','admin');

#
# Structure for table "banji"
#

DROP TABLE IF EXISTS `banji`;
CREATE TABLE `banji` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `rs` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COMMENT='班级信息表';

#
# Data for table "banji"
#

INSERT INTO `banji` VALUES (2,'101班',40),(3,'102班',40),(4,'201班',45),(5,'202班',45);

#
# Structure for table "baoxiu"
#

DROP TABLE IF EXISTS `baoxiu`;
CREATE TABLE `baoxiu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `susheid` int(11) DEFAULT NULL,
  `bxinfo` varchar(255) DEFAULT NULL,
  `bxsj` varchar(20) DEFAULT NULL,
  `chuli` varchar(255) DEFAULT NULL,
  `clsj` varchar(20) DEFAULT NULL,
  `state` varchar(20) DEFAULT NULL,
  `sid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='报修信息表';

#
# Data for table "baoxiu"
#

INSERT INTO `baoxiu` VALUES (1,3,'宿舍灯坏了','2018-03-06 16:12:03','已安排工人处理','2018-03-06 16:12:38','已处理',1);

#
# Structure for table "gonggao"
#

DROP TABLE IF EXISTS `gonggao`;
CREATE TABLE `gonggao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) DEFAULT NULL,
  `contents` varchar(500) DEFAULT NULL,
  `fbsj` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='公告信息表';

#
# Data for table "gonggao"
#

INSERT INTO `gonggao` VALUES (2,'新学期开学典礼通知','新学期开学典礼通知','2018-01-18 14:33:28');

#
# Structure for table "laifang"
#

DROP TABLE IF EXISTS `laifang`;
CREATE TABLE `laifang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `idno` varchar(20) DEFAULT NULL,
  `lfsj` varchar(20) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "laifang"
#

INSERT INTO `laifang` VALUES (2,'张明三','68788198910199989','2018-03-06 14:56:42','找人');

#
# Structure for table "shuifei"
#

DROP TABLE IF EXISTS `shuifei`;
CREATE TABLE `shuifei` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `susheid` int(11) DEFAULT NULL,
  `susheadmin` int(11) DEFAULT NULL,
  `feemonth` varchar(20) DEFAULT NULL,
  `fujian` varchar(255) DEFAULT NULL,
  `fee` double(4,1) DEFAULT '0.0',
  `nums` int(11) DEFAULT NULL,
  `dnums` int(11) DEFAULT NULL,
  `dfee` double(4,1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='水费信息表';

#
# Data for table "shuifei"
#

INSERT INTO `shuifei` VALUES (1,3,NULL,'2018-02',NULL,34.5,23,150,150.0);

#
# Structure for table "student"
#

DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sno` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `sex` varchar(10) DEFAULT NULL,
  `banji` int(11) DEFAULT NULL,
  `rxnf` varchar(50) DEFAULT NULL,
  `yuanxi` varchar(50) DEFAULT NULL,
  `mtel` varchar(50) DEFAULT NULL,
  `ftel` varchar(50) DEFAULT NULL,
  `susheid` int(11) DEFAULT NULL,
  `upwd` varchar(50) DEFAULT NULL,
  `state` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COMMENT='学生信息表';

#
# Data for table "student"
#

INSERT INTO `student` VALUES (1,'201801001','张明明','男',2,'2018','计算机','15567888878','15567889999',3,'123456','在校'),(2,'201801002','刘大磊','男',2,'2018','计算机','15567812222','18344455555',3,'123456','在校'),(3,'201801003','李霞','女',2,'2018','计算机','15567815678','18398777878',6,'123456','在校'),(4,'201801004','张芳','女',2,'2018','计算机','15567816666','18344477777',5,'123456','在校'),(5,'201801005','刘敏','女',2,'2018','计算机','15567817878','18349898989',5,'123456','在校'),(6,'201802001','王芳','女',3,'2018','计算机','15567817845','15567817821',5,'123456','在校'),(7,'201802002','王小敏','女',3,'2018','计算机','15567817855','15567817878',5,'123456','离校');

#
# Structure for table "sushe"
#

DROP TABLE IF EXISTS `sushe`;
CREATE TABLE `sushe` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `rnrs` int(11) DEFAULT NULL,
  `xjrs` int(11) DEFAULT NULL,
  `sushelouid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='宿舍信息表';

#
# Data for table "sushe"
#

INSERT INTO `sushe` VALUES (3,'101',4,2,4),(4,'102',4,0,4),(5,'101',4,3,5),(6,'102',4,1,5);

#
# Structure for table "sushelou"
#

DROP TABLE IF EXISTS `sushelou`;
CREATE TABLE `sushelou` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `scount` int(11) DEFAULT NULL,
  `tnums` int(11) DEFAULT NULL,
  `mid` int(11) DEFAULT NULL,
  `sex` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='宿舍楼信息表';

#
# Data for table "sushelou"
#

INSERT INTO `sushelou` VALUES (4,'A1',20,80,3,'男'),(5,'A2',20,80,4,'女');
